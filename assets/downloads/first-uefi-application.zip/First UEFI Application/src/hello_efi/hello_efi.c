#include <efi.h>
#include <efilib.h>

EFI_STATUS
EFIAPI
efi_main (EFI_HANDLE ImageHandle, EFI_SYSTEM_TABLE *SystemTable) {
  // Allows UEFI to set up some resources for you
  InitializeLib(ImageHandle, SystemTable);

  // Print() can take a format string, much like printf()
  // You have to use UTF-16 strings for basically all UEFI calls
  Print(L"Hello, world!\n");

  return EFI_SUCCESS;
}